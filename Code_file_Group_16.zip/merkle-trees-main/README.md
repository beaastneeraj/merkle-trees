User has to first input the length of the string which he wants to encrypt.
Then he has to enter the string
in the output user will get the hexadecimal hash code of the input string 